var searchData=
[
  ['_7estudentas_0',['~Studentas',['../class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23',1,'Studentas']]],
  ['_7ezmogus_1',['~Zmogus',['../class_zmogus.html#a111f690f499186555a4f318cb1868f32',1,'Zmogus']]]
];
