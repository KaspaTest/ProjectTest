var searchData=
[
  ['func_0',['func',['../_libas_8cpp.html#a99a5a6cb840d7fb3cd9ee25bccf9e4a8',1,'func(studentas st):&#160;Libas.cpp'],['../_libas_8h.html#a99a5a6cb840d7fb3cd9ee25bccf9e4a8',1,'func(studentas st):&#160;Libas.cpp']]]
];
