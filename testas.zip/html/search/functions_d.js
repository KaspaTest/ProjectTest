var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#afac4cdd0cd4ac005ac7efdfac5571096',1,'Zmogus::vardas()'],['../class_studentas.html#a312e7a75f38153fe8358751b07e8c787',1,'Studentas::vardas()']]],
  ['vidurkis_1',['vidurkis',['../class_studentas.html#ac96b1fcfdbb3335e45a3de293bcd2a7e',1,'Studentas']]]
];
