var searchData=
[
  ['galbalas_0',['galBalas',['../class_studentas.html#ad67d64fa30f3cdf2ce303be79f1c6a99',1,'Studentas']]],
  ['galutinisvid_1',['galutinisVid',['../class_studentas.html#a0fbc1e2b43cfa7414c90cef8bbdb2b2d',1,'Studentas']]]
];
