var searchData=
[
  ['vardas_0',['vardas',['../structstudentas.html#a12c7418eb835240f31d00a3ebf7b22bf',1,'studentas']]],
  ['vardas_5f_1',['vardas_',['../class_zmogus.html#a09b290c9be6039ce3a94e1557def9b3a',1,'Zmogus']]]
];
