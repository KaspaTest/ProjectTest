var searchData=
[
  ['zmogus_0',['Zmogus',['../class_zmogus.html',1,'Zmogus'],['../class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574',1,'Zmogus::Zmogus()']]]
];
